This is an indicator for Wingpanel. It started as a hacky port of Robert
Ancell's Vala network indicator for dbus.

The backend used is NetworkManager, with some custom vapi in src (check
regularly that it is still needed).
